import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.serenity.cloudspa',
  appName: 'Serenity Cloud Spa',
  webDir: 'dist'
};

export default config;
