import { chmodSync } from 'fs';
import { join } from 'path';

try {
  chmodSync(join(process.cwd(), 'android', 'gradlew'), 0o755);
  console.log('Successfully set executable permissions on android/gradlew');
} catch (error) {
  console.error('Failed to set permissions:', error);
  process.exit(1);
}
