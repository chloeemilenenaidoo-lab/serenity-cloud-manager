/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { Component, useState, useEffect, useMemo, FormEvent, ErrorInfo } from 'react';
import { Capacitor } from '@capacitor/core';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PlusCircle, 
  History, 
  TrendingUp, 
  User, 
  Trash2, 
  CheckCircle2,
  Calendar,
  Phone,
  ChevronRight,
  Mail,
  DollarSign,
  Users,
  Star,
  BarChart3,
  Search,
  BookOpen,
  Clock,
  Plus,
  LayoutDashboard,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  Download,
  Lock,
  LogOut,
  AlertCircle,
  Eye,
  EyeOff
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  Cell, 
  PieChart, 
  Pie 
} from 'recharts';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  signInAnonymously,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  GoogleAuthProvider, 
  signOut, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  doc, 
  query, 
  orderBy,
  where,
  setDoc,
  getDoc
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { handleFirestoreError, OperationType, testConnection } from './services/firestore';

interface Sale {
  id: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  serviceType: string;
  price: number;
  paymentMethod: 'Cash' | 'Card' | 'EFT';
  timestamp: number;
  createdBy: string;
  cashierName: string;
  isCancelled?: boolean;
  cancellationReason?: string;
  cancelledBy?: string;
  cancelledAt?: number;
}

interface Booking {
  id: string;
  customerName: string;
  serviceType: string;
  date: string;
  time: string;
  timestamp: number;
  createdBy: string;
  isCancelled?: boolean;
  cancellationReason?: string;
  cancelledBy?: string;
  cancelledAt?: number;
}

const SERVICES = [
  { name: 'Swedish Massage', price: 150, duration: '45 Minutes | Full Body' },
  { name: 'Deep Tissue Massage', price: 250, duration: '45 Minutes | Full Body' },
  { name: 'Hot Oil Massage', price: 300, duration: '45 Minutes | Full Body' },
  { name: 'Hot Stone Massage', price: 350, duration: '45 Minutes | Full Body' },
];

const CONTACT_NUMBER = "062 828 4628";

// Error Boundary Component
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      let displayError = "Something went wrong.";
      let details = null;

      try {
        const parsed = JSON.parse(this.state.error.message);
        if (parsed.error && parsed.operationType) {
          displayError = `Firestore ${parsed.operationType} Error`;
          details = parsed;
        }
      } catch (e) {
        displayError = this.state.error.message || String(this.state.error);
      }

      return (
        <div className="min-h-screen bg-spa-cream flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl p-8 text-center border border-spa-gold/20">
            <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertCircle className="text-red-500 w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-spa-ink mb-2">{displayError}</h2>
            <p className="text-spa-ink/60 mb-8 serif italic">
              {details ? `An error occurred while performing a ${details.operationType} operation on ${details.path}.` : "An unexpected error occurred. Please try refreshing the page."}
            </p>
            {details && (
              <div className="bg-spa-cream/30 rounded-xl p-4 mb-8 text-left overflow-auto max-h-48">
                <pre className="text-[10px] font-mono text-spa-ink/70">
                  {JSON.stringify(details, null, 2)}
                </pre>
              </div>
            )}
            <button
              onClick={() => window.location.reload()}
              className="w-full py-4 bg-spa-ink text-white font-bold uppercase tracking-widest text-xs rounded-xl hover:bg-spa-ink/90 transition-all"
            >
              Refresh Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}

function MainApp() {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [selectedServiceIndex, setSelectedServiceIndex] = useState<number | null>(null);
  const [isCustomService, setIsCustomService] = useState(false);
  const [customServiceName, setCustomServiceName] = useState('');
  const [customServicePrice, setCustomServicePrice] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Card' | 'EFT'>('Cash');
  const [cashierName, setCashierName] = useState('');
  const [sales, setSales] = useState<Sale[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showBookingSuccess, setShowBookingSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'log' | 'clients' | 'bookings' | 'reports'>('log');
  const [customerSearch, setCustomerSearch] = useState('');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  useEffect(() => {
    testConnection(db);
  }, []);

  // Cancellation State
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancellingSaleId, setCancellingSaleId] = useState<string | null>(null);
  const [cancellingBookingId, setCancellingBookingId] = useState<string | null>(null);
  const [cancellationReason, setCancellationReason] = useState('');
  const [cancellingAdminName, setCancellingAdminName] = useState('');

  // Authentication State
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [email, setEmail] = useState('jodenenaidoo00@gmail.com');
  const [password, setPassword] = useState('');
  const [staffPassword, setStaffPassword] = useState('');
  const [loginMode, setLoginMode] = useState<'admin' | 'staff'>('admin');
  const [showPassword, setShowPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [isSigningUp, setIsSigningUp] = useState(false);

  // Booking Form State
  const [bookingName, setBookingName] = useState('');
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookingServiceIndex, setBookingServiceIndex] = useState<number | null>(null);

  // API URL for mobile/web compatibility
  const API_URL = Capacitor.getPlatform() === 'web' ? '' : (import.meta.env.VITE_API_URL || '');

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            setUserRole(userDoc.data().role);
            setUser(firebaseUser);
          } else {
            // This case might happen if a user is created in Auth but not in Firestore yet
            // We'll handle this in the login/signup functions
            setUser(firebaseUser);
          }
        } catch (e) {
          console.error("Error checking user profile:", e);
          setUser(null);
        }
      } else {
        setUser(null);
        setUserRole(null);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Load all data from Firestore on mount
  useEffect(() => {
    if (!isAuthReady || !user || !userRole) return;

    testConnection(db);

    let salesQuery;
    let bookingsQuery;

    if (userRole === 'admin') {
      salesQuery = query(collection(db, 'sales'));
      bookingsQuery = query(collection(db, 'bookings'));
    } else {
      // Staff only sees what they submitted
      salesQuery = query(
        collection(db, 'sales'), 
        where('createdBy', '==', user.uid)
      );
      bookingsQuery = query(
        collection(db, 'bookings'), 
        where('createdBy', '==', user.uid)
      );
    }

    const unsubscribeSales = onSnapshot(salesQuery, (snapshot) => {
      const salesData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Sale));
      setSales(salesData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'sales');
    });

    const unsubscribeBookings = onSnapshot(bookingsQuery, (snapshot) => {
      const bookingsData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as Booking));
      setBookings(bookingsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'bookings');
    });

    return () => {
      unsubscribeSales();
      unsubscribeBookings();
    };
  }, [isAuthReady, user, userRole]);

  const todaySales = useMemo(() => {
    const today = new Date().setHours(0, 0, 0, 0);
    return sales
      .filter((s: Sale) => new Date(s.timestamp).setHours(0, 0, 0, 0) === today)
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [sales]);

  const weeklySales = useMemo(() => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    sevenDaysAgo.setHours(0, 0, 0, 0);
    return sales
      .filter((s: Sale) => s.timestamp >= sevenDaysAgo.getTime())
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [sales]);

  const monthlySales = useMemo(() => {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    return sales.filter((s: Sale) => s.timestamp >= startOfMonth);
  }, [sales]);

  const dashboardMetrics = useMemo(() => {
    const activeTodaySales = todaySales.filter(s => !s.isCancelled);
    const activeMonthlySales = monthlySales.filter(s => !s.isCancelled);

    const todayTotal = activeTodaySales.reduce((sum, s) => sum + s.price, 0);
    const todayCustomers = activeTodaySales.length;
    const monthlyTotal = activeMonthlySales.reduce((sum, s) => sum + s.price, 0);

    // Calculate totals per payment method for today
    const todayPaymentTotals = {
      Cash: activeTodaySales.filter(s => s.paymentMethod === 'Cash').reduce((sum, s) => sum + s.price, 0),
      Card: activeTodaySales.filter(s => s.paymentMethod === 'Card').reduce((sum, s) => sum + s.price, 0),
      EFT: activeTodaySales.filter(s => s.paymentMethod === 'EFT').reduce((sum, s) => sum + s.price, 0),
    };

    // Calculate most popular service
    const serviceCounts: Record<string, number> = {};
    sales.filter(s => !s.isCancelled).forEach(s => {
      serviceCounts[s.serviceType] = (serviceCounts[s.serviceType] || 0) + 1;
    });

    let popular = "None";
    let maxCount = 0;
    Object.entries(serviceCounts).forEach(([name, count]) => {
      if (count > maxCount) {
        maxCount = count;
        popular = name;
      }
    });

    return {
      todayTotal,
      todayCustomers,
      monthlyTotal,
      todayPaymentTotals,
      popularService: popular
    };
  }, [todaySales, monthlySales, sales]);

  const customers = useMemo(() => {
    const customerMap: Record<string, {
      name: string;
      phone: string;
      email: string;
      lastVisit: number;
      services: string[];
    }> = {};

    sales.filter(sale => !sale.isCancelled).forEach(sale => {
      const key = `${sale.customerName.toLowerCase()}-${sale.customerPhone}`;
      if (!customerMap[key]) {
        customerMap[key] = {
          name: sale.customerName,
          phone: sale.customerPhone,
          email: sale.customerEmail,
          lastVisit: sale.timestamp,
          services: [sale.serviceType]
        };
      } else {
        if (sale.timestamp > customerMap[key].lastVisit) {
          customerMap[key].lastVisit = sale.timestamp;
          customerMap[key].name = sale.customerName; // Keep latest casing
        }
        if (!customerMap[key].services.includes(sale.serviceType)) {
          customerMap[key].services.push(sale.serviceType);
        }
      }
    });

    return Object.values(customerMap).sort((a, b) => b.lastVisit - a.lastVisit);
  }, [sales]);

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => 
      c.name.toLowerCase().includes(customerSearch.toLowerCase())
    );
  }, [customers, customerSearch]);

  const handleSaveBooking = async (e: FormEvent) => {
    e.preventDefault();
    if (!bookingName || !bookingDate || !bookingTime || bookingServiceIndex === null) return;

    const newBooking = {
      customerName: bookingName,
      serviceType: SERVICES[bookingServiceIndex].name,
      date: bookingDate,
      time: bookingTime,
      timestamp: Date.now(),
      createdBy: user?.uid || 'unknown',
      isCancelled: false
    };

    try {
      await addDoc(collection(db, 'bookings'), newBooking);
      setBookingName('');
      setBookingDate('');
      setBookingTime('');
      setBookingServiceIndex(null);
      setShowBookingSuccess(true);
      setTimeout(() => setShowBookingSuccess(false), 3000);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'bookings');
    }
  };

  const handleDeleteBooking = (id: string) => {
    // Function disabled as per requirements
    console.log("Deletion disabled", id);
  };

  const allBookings = useMemo(() => {
    return [...bookings].sort((a, b) => {
      const dateA = new Date(`${a.date} ${a.time}`).getTime();
      const dateB = new Date(`${b.date} ${b.time}`).getTime();
      return dateB - dateA; // Show newest first for history
    });
  }, [bookings]);

  const handleResetPassword = async () => {
    const trimmedPassword = password.trim();
    let adminEmail = 'jodenenaidoo00@gmail.com'; // Default
    
    if (trimmedPassword === 'Chloe12') {
      adminEmail = 'chloe.emilene.naidoo@gmail.com';
    }

    try {
      await sendPasswordResetEmail(auth, adminEmail);
      setResetSent(true);
      setLoginError(null);
      setTimeout(() => setResetSent(false), 5000);
    } catch (e: any) {
      setLoginError(`Reset failed: ${e.message}`);
    }
  };

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    
    const trimmedPassword = password.trim();
    let adminEmail = '';

    if (trimmedPassword === 'Jodene12') {
      adminEmail = 'jodenenaidoo00@gmail.com';
    } else if (trimmedPassword === 'Chloe12') {
      adminEmail = 'chloe.emilene.naidoo@gmail.com';
    } else {
      setLoginError("Invalid Admin Password");
      return;
    }

    try {
      let result;
      try {
        result = await signInWithEmailAndPassword(auth, adminEmail, trimmedPassword);
      } catch (signInError: any) {
        // If user doesn't exist, try to create it (initial setup)
        if (signInError.code === 'auth/user-not-found' || signInError.code === 'auth/invalid-credential') {
          try {
            result = await createUserWithEmailAndPassword(auth, adminEmail, trimmedPassword);
          } catch (signUpError: any) {
            // If creation fails because email exists, it means the original error was actually a wrong password
            if (signUpError.code === 'auth/email-already-in-use') {
              setLoginError("Invalid Admin Password. Please try again.");
              return;
            }
            throw signUpError;
          }
        } else {
          throw signInError;
        }
      }

      if (result) {
        const userDoc = await getDoc(doc(db, 'users', result.user.uid));
        if (!userDoc.exists()) {
          await setDoc(doc(db, 'users', result.user.uid), {
            uid: result.user.uid,
            email: adminEmail,
            role: 'admin',
            displayName: adminEmail === 'jodenenaidoo00@gmail.com' ? 'Admin Jodene' : 'Admin Chloe'
          });
        }
        setUserRole('admin');
      }
    } catch (e: any) {
      console.error("Admin login failed:", e);
      if (e.code === 'auth/operation-not-allowed') {
        setLoginError("ACTION REQUIRED: Please enable 'Email/Password' in your Firebase Console (Authentication > Sign-in method).");
      } else if (e.code === 'auth/network-request-failed') {
        setLoginError("Network error. Please check your internet connection.");
      } else {
        setLoginError(`Login failed: ${e.message || "Please check your Firebase settings."}`);
      }
    }
  };

  const handleStaffLogin = async (e: FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    if (staffPassword.trim() === 'Serenity2026') {
      try {
        const result = await signInAnonymously(auth);
        const userRef = doc(db, 'users', result.user.uid);
        
        const userDoc = await getDoc(userRef);
        if (!userDoc.exists()) {
          await setDoc(userRef, {
            uid: result.user.uid,
            role: 'staff',
            displayName: 'Staff Member',
            createdAt: Date.now()
          });
        }
        
        setUserRole('staff');
      } catch (e: any) {
        console.error("Staff login failed:", e);
        if (e.code === 'auth/admin-restricted-operation' || e.code === 'auth/operation-not-allowed') {
          setLoginError("ACTION REQUIRED: Please enable 'Anonymous' auth in your Firebase Console (Authentication > Sign-in method).");
        } else if (e.message?.includes('permission') || e.code === 'permission-denied') {
          handleFirestoreError(e, OperationType.WRITE, 'users');
        } else {
          setLoginError("Staff access failed. Please check your Firebase settings.");
        }
      }
    } else {
      setLoginError("Invalid Staff Password");
      setStaffPassword('');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error("Logout failed:", e);
    }
  };

  const reportData = useMemo(() => {
    // Daily Sales (Last 7 days)
    const dailyMap: Record<string, number> = {};
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const key = d.toLocaleDateString('en-ZA', { day: '2-digit', month: 'short' });
      dailyMap[key] = 0;
    }

    const activeSales = sales.filter(s => !s.isCancelled);

    activeSales.forEach(s => {
      const date = new Date(s.timestamp);
      const key = date.toLocaleDateString('en-ZA', { day: '2-digit', month: 'short' });
      if (dailyMap[key] !== undefined) {
        dailyMap[key] += s.price;
      }
    });

    const dailyChart = Object.entries(dailyMap).map(([name, value]) => ({ name, value }));

    // Monthly Income (Current Year)
    const monthlyMap: Record<string, number> = {};
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    months.forEach(m => monthlyMap[m] = 0);

    activeSales.forEach(s => {
      const date = new Date(s.timestamp);
      if (date.getFullYear() === selectedYear) {
        const key = months[date.getMonth()];
        monthlyMap[key] += s.price;
      }
    });

    const monthlyChart = Object.entries(monthlyMap).map(([name, value]) => ({ name, value }));

    // Payment Method Distribution
    const paymentMap: Record<string, number> = { Cash: 0, Card: 0, EFT: 0 };
    activeSales.forEach(s => {
      paymentMap[s.paymentMethod] += s.price;
    });
    const paymentChart = Object.entries(paymentMap).map(([name, value]) => ({ name, value }));

    // Weekly Report (Last 4 weeks)
    const weeklyChart: { name: string; value: number }[] = [];
    for (let i = 3; i >= 0; i--) {
      const start = new Date(now);
      start.setDate(start.getDate() - (i * 7 + 7));
      const end = new Date(now);
      end.setDate(end.getDate() - (i * 7));
      
      const weekSales = activeSales.filter(s => s.timestamp >= start.getTime() && s.timestamp <= end.getTime());
      const total = weekSales.reduce((sum, s) => sum + s.price, 0);
      weeklyChart.push({ 
        name: `Week -${i}`, 
        value: total 
      });
    }

    return { dailyChart, monthlyChart, paymentChart, weeklyChart };
  }, [sales, selectedYear]);

  const handleSaveSale = async (e: FormEvent) => {
    e.preventDefault();
    if (!customerName || !cashierName) return;
    if (!isCustomService && selectedServiceIndex === null) return;
    if (isCustomService && (!customServiceName || !customServicePrice)) return;

    const finalPrice = isCustomService ? Number(customServicePrice) : SERVICES[selectedServiceIndex!].price;
    const finalService = isCustomService ? customServiceName : SERVICES[selectedServiceIndex!].name;

    const newSale = {
      customerName,
      customerPhone,
      customerEmail,
      serviceType: finalService,
      price: finalPrice,
      paymentMethod,
      timestamp: Date.now(),
      createdBy: user?.uid || 'unknown',
      cashierName: cashierName,
      isCancelled: false
    };

    try {
      await addDoc(collection(db, 'sales'), newSale);
      setCustomerName('');
      setCustomerPhone('');
      setCustomerEmail('');
      setSelectedServiceIndex(null);
      setIsCustomService(false);
      setCustomServiceName('');
      setCustomServicePrice('');
      setPaymentMethod('Cash');
      setCashierName('');
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'sales');
    }
  };

  const handleConfirmCancellation = async (e: FormEvent) => {
    e.preventDefault();
    if (!cancellationReason || !cancellingAdminName) return;

    const cancellationData = {
      isCancelled: true,
      cancellationReason: cancellationReason,
      cancelledBy: cancellingAdminName,
      cancelledAt: Date.now()
    };

    try {
      if (cancellingSaleId) {
        await updateDoc(doc(db, 'sales', cancellingSaleId), cancellationData);
      } else if (cancellingBookingId) {
        await updateDoc(doc(db, 'bookings', cancellingBookingId), cancellationData);
      }
      setShowCancelModal(false);
      setCancellingSaleId(null);
      setCancellingBookingId(null);
      setCancellationReason('');
      setCancellingAdminName('');
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, cancellingSaleId ? 'sales' : 'bookings');
    }
  };

  const totalIncome = useMemo(() => {
    return todaySales.filter(s => !s.isCancelled).reduce((sum, sale) => sum + sale.price, 0);
  }, [todaySales]);

  const todayDate = new Date().toLocaleDateString('en-ZA', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  if (!isAuthReady) {
    return (
      <div className="min-h-screen bg-spa-cream flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-spa-gold border-t-transparent rounded-full animate-spin"></div>
          <p className="text-[10px] font-bold uppercase tracking-[0.3em] text-spa-gold">Loading Serenity...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-spa-cream flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white p-12 shadow-2xl border border-spa-gold/20 text-center"
        >
          <div className="mb-8 flex justify-center">
            <div className="w-24 h-24 rounded-full bg-spa-cream/50 p-2 flex items-center justify-center border border-spa-gold/20 shadow-inner overflow-hidden">
              <img 
                src="/logo.png" 
                alt="Serenity Logo" 
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  const fallback = document.createElement('div');
                  fallback.className = 'text-spa-gold flex items-center justify-center';
                  fallback.innerHTML = `
                    <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                      <path d="M12 8c-2 0-3 1-3 3s1 3 3 5c2-2 3-3 3-5s-1-3-3-3z"/>
                      <path d="M9 11c0-2 1-3 3-3s3 1 3 3"/>
                    </svg>
                  `;
                  e.currentTarget.parentElement!.appendChild(fallback);
                }}
              />
            </div>
          </div>
          
          <h1 className="text-3xl display font-bold tracking-[0.2em] uppercase mb-2 text-spa-ink">
            Serenity
          </h1>
          <h2 className="text-sm font-medium tracking-[0.4em] text-spa-gold-dark uppercase mb-8">
            Cloud Login
          </h2>

          <div className="flex border-b border-spa-gold/10 mb-8">
            <button 
              onClick={() => { setLoginMode('admin'); setLoginError(null); }}
              className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${loginMode === 'admin' ? 'text-spa-gold border-b-2 border-spa-gold' : 'text-spa-gold/40'}`}
            >
              Admin
            </button>
            <button 
              onClick={() => { setLoginMode('staff'); setLoginError(null); }}
              className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-all ${loginMode === 'staff' ? 'text-spa-gold border-b-2 border-spa-gold' : 'text-spa-gold/40'}`}
            >
              Staff
            </button>
          </div>

          {loginMode === 'admin' ? (
            <form onSubmit={handleLogin} className="space-y-6">
              <p className="text-spa-ink/60 serif italic text-sm mb-4">
                Management access for authorized administrators only.
              </p>

              <div className="space-y-4">
                <div className="text-left">
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-2">Admin Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-4 bg-spa-cream/30 border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 text-center text-2xl tracking-widest"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-spa-gold/40 hover:text-spa-gold"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {loginError && (
                <div className="space-y-2">
                  <p className="text-red-600 text-[10px] font-bold uppercase tracking-widest bg-red-50 p-2 border border-red-100">
                    {loginError}
                  </p>
                  <button 
                    type="button"
                    onClick={handleResetPassword}
                    className="text-[9px] font-bold uppercase tracking-widest text-spa-gold hover:underline"
                  >
                    Forgot Password? Reset via Email
                  </button>
                </div>
              )}

              {resetSent && (
                <p className="text-emerald-600 text-[10px] font-bold uppercase tracking-widest bg-emerald-50 p-2 border border-emerald-100">
                  Reset link sent to jodenenaidoo00@gmail.com
                </p>
              )}

              <button
                type="submit"
                className="w-full py-5 bg-spa-ink text-white font-bold uppercase tracking-[0.3em] text-xs hover:bg-spa-ink/90 transition-all shadow-xl active:scale-[0.98]"
              >
                Admin Login
              </button>
            </form>
          ) : (
            <form onSubmit={handleStaffLogin} className="space-y-6">
              <p className="text-spa-ink/60 serif italic text-sm mb-4">
                Staff access for authorized workers only.
              </p>

              <div className="space-y-4">
                <div className="text-left">
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-2">Staff Password</label>
                  <input
                    type="password"
                    required
                    value={staffPassword}
                    onChange={(e) => setStaffPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-4 bg-spa-cream/30 border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 text-center text-2xl tracking-widest"
                  />
                </div>
              </div>

              {loginError && (
                <p className="text-red-600 text-[10px] font-bold uppercase tracking-widest bg-red-50 p-2 border border-red-100">
                  {loginError}
                </p>
              )}

              <button
                type="submit"
                className="w-full py-5 bg-spa-ink text-white font-bold uppercase tracking-[0.3em] text-xs hover:bg-spa-ink/90 transition-all shadow-xl active:scale-[0.98]"
              >
                Staff Access
              </button>
            </form>
          )}

          <p className="mt-12 text-[9px] uppercase tracking-[0.2em] text-spa-gold/80">
            Authorized Personnel Only
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-12 bg-spa-cream">
      {/* Header / Logo Section */}
      <header className="bg-white border-b border-spa-gold/20 py-16 px-4 shadow-sm relative overflow-hidden">
        <button 
          onClick={handleLogout}
          className="absolute top-8 right-8 flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-spa-gold/40 hover:text-spa-gold transition-colors z-20"
        >
          <LogOut className="w-3 h-3" /> Logout
        </button>
        <div className="absolute top-0 left-0 w-full h-1 bg-spa-gold"></div>
        
        {/* Subtle Cloud Background Elements */}
        <div className="absolute top-10 left-10 opacity-5 pointer-events-none">
          <svg width="200" height="100" viewBox="0 0 200 100" fill="currentColor" className="text-spa-gold">
            <path d="M40 60c0-11 9-20 20-20 2-11 12-20 23-20 13 0 23 10 23 23 9 0 17 8 17 17s-8 17-17 17H60c-11 0-20-9-20-17z" />
          </svg>
        </div>
        <div className="absolute bottom-10 right-10 opacity-5 pointer-events-none">
          <svg width="200" height="100" viewBox="0 0 200 100" fill="currentColor" className="text-spa-gold">
            <path d="M40 60c0-11 9-20 20-20 2-11 12-20 23-20 13 0 23 10 23 23 9 0 17 8 17 17s-8 17-17 17H60c-11 0-20-9-20-17z" />
          </svg>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center text-center max-w-2xl mx-auto relative z-10"
        >
          {/* Custom Cloud Logo */}
          <div className="mb-6 flex justify-center">
            <div className="w-32 h-32 rounded-full bg-spa-cream/30 p-4 flex items-center justify-center border border-spa-gold/10 shadow-sm overflow-hidden">
              <img 
                src="/logo.png" 
                alt="Serenity Logo" 
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  const fallback = document.createElement('div');
                  fallback.className = 'text-spa-gold flex items-center justify-center';
                  fallback.innerHTML = `
                    <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                      <path d="M12 8c-2 0-3 1-3 3s1 3 3 5c2-2 3-3 3-5s-1-3-3-3z"/>
                      <path d="M9 11c0-2 1-3 3-3s3 1 3 3"/>
                    </svg>
                  `;
                  e.currentTarget.parentElement!.appendChild(fallback);
                }}
              />
            </div>
          </div>

          {/* Logo Text Branding - Reduced size as requested */}
          <div className="mb-4">
            <h1 className="text-4xl display font-bold tracking-[0.2em] uppercase mb-1 text-spa-ink">
              Serenity
            </h1>
            <h2 className="text-lg font-medium tracking-[0.4em] text-spa-gold-dark uppercase">
              Cloud Spa
            </h2>
          </div>
          
          <div className="h-[1px] w-32 bg-spa-gold/30 mb-6"></div>
          
          <p className="serif italic text-spa-ink/60 text-xl mb-8 tracking-wide">
            Serenity within...
          </p>

          <div className="flex items-center gap-10 text-[10px] font-bold uppercase tracking-[0.3em] text-spa-gold/60">
            <span className="flex items-center gap-2">
              <Calendar className="w-3 h-3" /> {todayDate}
            </span>
          </div>
        </motion.div>
      </header>

      <main className="max-w-6xl mx-auto px-4 mt-12">
        {/* Dashboard Section */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {userRole === 'admin' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="luxury-card p-6 flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-full bg-spa-gold/10 flex items-center justify-center text-spa-gold">
                <DollarSign className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-spa-gold/60">Today's Sales</p>
                <p className="text-2xl font-light serif text-spa-ink">R{dashboardMetrics.todayTotal}</p>
              </div>
            </motion.div>
          )}

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="luxury-card p-6 flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-full bg-spa-gold/10 flex items-center justify-center text-spa-gold">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-spa-gold/60">Customers Today</p>
              <p className="text-2xl font-light serif text-spa-ink">{dashboardMetrics.todayCustomers}</p>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="luxury-card p-6 flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-full bg-spa-gold/10 flex items-center justify-center text-spa-gold">
              <Star className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-spa-gold/60">Popular Service</p>
              <p className="text-lg font-light serif text-spa-ink truncate max-w-[150px]">{dashboardMetrics.popularService}</p>
            </div>
          </motion.div>

          {userRole === 'admin' && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="luxury-card p-6 flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-full bg-spa-gold/10 flex items-center justify-center text-spa-gold">
                <BarChart3 className="w-6 h-6" />
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-spa-gold/60">Monthly Income</p>
                <p className="text-2xl font-light serif text-spa-ink">R{dashboardMetrics.monthlyTotal}</p>
              </div>
            </motion.div>
          )}
        </section>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start pb-24">
        
        {/* Left Column: New Sale Form (4 cols) */}
        <section className="lg:col-span-5 lg:sticky lg:top-8">
          <div className="bg-white rounded-none p-8 shadow-xl border border-spa-gold/10 relative">
            <div className="flex items-center justify-between mb-8 border-b border-spa-gold/10 pb-4">
              <div className="flex items-center gap-3">
                <PlusCircle className="w-5 h-5 text-spa-gold" />
                <h2 className="text-2xl serif font-medium text-spa-ink uppercase tracking-widest">New Sale</h2>
              </div>
              <svg width="40" height="30" viewBox="0 0 120 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-spa-gold opacity-60">
                <path d="M25 65c-10 0-18-8-18-18 0-9 7-16 16-17 1-10 10-18 20-18 8 0 15 5 18 12 3-2 6-3 10-3 9 0 16 7 16 16 0 1-1 2-1 3 8 2 14 9 14 17 0 10-8 18-18 18H25z" stroke="currentColor" strokeWidth="2" fill="none" />
              </svg>
            </div>

            <form onSubmit={handleSaveSale} className="space-y-8">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">
                  Customer Name
                </label>
                <div className="relative group">
                  <User className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Enter customer name..."
                    className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 serif text-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">
                    Phone Number <span className="text-spa-gold/40 lowercase italic font-normal">(Optional)</span>
                  </label>
                  <div className="relative group">
                    <Phone className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="e.g. 012 345 6789"
                      className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 serif text-lg"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">
                    Email Address <span className="text-spa-gold/40 lowercase italic font-normal">(Optional)</span>
                  </label>
                  <div className="relative group">
                    <Mail className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="customer@email.com"
                      className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 serif text-lg"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-4">
                  Select Treatment
                </label>
                <div className="grid grid-cols-1 gap-4">
                  {SERVICES.map((service, index) => (
                    <button
                      key={service.name}
                      type="button"
                      onClick={() => {
                        setSelectedServiceIndex(index);
                        setIsCustomService(false);
                      }}
                      className={`group flex justify-between items-center p-5 border transition-all text-left relative overflow-hidden ${
                        selectedServiceIndex === index && !isCustomService
                          ? 'bg-spa-ink text-white border-spa-ink shadow-2xl translate-x-2'
                          : 'bg-white border-spa-gold/20 text-spa-ink hover:border-spa-gold/60'
                      }`}
                    >
                      <div className="relative z-10">
                        <div className={`font-medium serif text-xl ${selectedServiceIndex === index && !isCustomService ? 'text-white' : 'text-spa-ink'}`}>
                          {service.name}
                        </div>
                        <div className={`text-[10px] uppercase tracking-widest mt-1 ${selectedServiceIndex === index && !isCustomService ? 'text-spa-gold' : 'text-spa-gold/60'}`}>
                          {service.duration}
                        </div>
                      </div>
                      <div className="relative z-10 flex flex-col items-end">
                        <span className={`text-xl font-light ${selectedServiceIndex === index && !isCustomService ? 'text-spa-gold' : 'text-spa-gold'}`}>
                          R{service.price}
                        </span>
                        <ChevronRight className={`w-4 h-4 mt-1 transition-transform ${selectedServiceIndex === index && !isCustomService ? 'translate-x-1 opacity-100' : 'opacity-0'}`} />
                      </div>
                      {selectedServiceIndex === index && !isCustomService && (
                        <div className="absolute right-0 top-0 bottom-0 w-1 bg-spa-gold"></div>
                      )}
                    </button>
                  ))}

                  {/* Custom Service Button */}
                  <button
                    type="button"
                    onClick={() => {
                      setIsCustomService(true);
                      setSelectedServiceIndex(null);
                    }}
                    className={`group flex justify-between items-center p-5 border transition-all text-left relative overflow-hidden ${
                      isCustomService
                        ? 'bg-spa-ink text-white border-spa-ink shadow-2xl translate-x-2'
                        : 'bg-white border-spa-gold/20 text-spa-ink hover:border-spa-gold/60'
                    }`}
                  >
                    <div className="relative z-10">
                      <div className={`font-medium serif text-xl ${isCustomService ? 'text-white' : 'text-spa-ink'}`}>
                        Other / Custom Service
                      </div>
                      <div className={`text-[10px] uppercase tracking-widest mt-1 ${isCustomService ? 'text-spa-gold' : 'text-spa-gold/60'}`}>
                        Specify name and price below
                      </div>
                    </div>
                    <PlusCircle className={`w-5 h-5 ${isCustomService ? 'text-spa-gold' : 'text-spa-gold/40'}`} />
                    {isCustomService && (
                      <div className="absolute right-0 top-0 bottom-0 w-1 bg-spa-gold"></div>
                    )}
                  </button>
                </div>
              </div>

              {isCustomService && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="space-y-6 pt-4 border-t border-spa-gold/10"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">
                        Service Name
                      </label>
                      <input
                        type="text"
                        required={isCustomService}
                        value={customServiceName}
                        onChange={(e) => setCustomServiceName(e.target.value)}
                        placeholder="e.g. Manicure"
                        className="w-full px-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">
                        Price (R)
                      </label>
                      <input
                        type="number"
                        required={isCustomService}
                        value={customServicePrice}
                        onChange={(e) => setCustomServicePrice(e.target.value)}
                        placeholder="e.g. 200"
                        className="w-full px-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-4">
                  Payment Method
                </label>
                <div className="grid grid-cols-3 gap-4">
                  {(['Cash', 'Card', 'EFT'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`py-3 border text-[10px] font-bold uppercase tracking-widest transition-all ${
                        paymentMethod === method
                          ? 'bg-spa-ink text-white border-spa-ink'
                          : 'bg-white border-spa-gold/20 text-spa-gold/60 hover:border-spa-gold/40'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">
                  Cashier / Responsible Person
                </label>
                <div className="relative group">
                  <User className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                  <input
                    type="text"
                    required
                    value={cashierName}
                    onChange={(e) => setCashierName(e.target.value)}
                    placeholder="Enter your name..."
                    className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 serif text-lg"
                  />
                </div>
              </div>

              {(selectedServiceIndex !== null || (isCustomService && customServicePrice)) && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-spa-cream/50 p-6 border border-spa-gold/10 flex justify-between items-center"
                >
                  <span className="text-[10px] font-bold uppercase tracking-widest text-spa-gold">Total Due</span>
                  <span className="text-3xl font-light text-spa-ink serif">R{isCustomService ? customServicePrice : SERVICES[selectedServiceIndex!].price}</span>
                </motion.div>
              )}

              <button
                type="submit"
                disabled={!customerName || !cashierName || (!isCustomService && selectedServiceIndex === null) || (isCustomService && (!customServiceName || !customServicePrice))}
                className="w-full py-5 bg-spa-gold text-white font-bold uppercase tracking-[0.3em] text-xs hover:bg-spa-gold/90 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-xl active:scale-[0.98] flex items-center justify-center gap-3"
              >
                <CheckCircle2 className="w-4 h-4" />
                Confirm Sale
              </button>
            </form>

            <AnimatePresence>
              {showSuccess && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="mt-6 p-4 bg-emerald-50 text-emerald-700 text-center text-[10px] font-bold uppercase tracking-widest border border-emerald-100"
                >
                  Transaction Recorded Successfully
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>

        {/* Right Column: Summary & History (7 cols) */}
        <section className="lg:col-span-7 space-y-12">
          {/* Tabs for Log vs Clients */}
          <div className="flex border-b border-spa-gold/10 overflow-x-auto no-scrollbar">
            <button 
              onClick={() => setActiveTab('log')}
              className={`px-8 py-4 text-[10px] font-bold uppercase tracking-[0.3em] transition-all relative ${
                activeTab === 'log' ? 'text-spa-gold' : 'text-spa-gold/30 hover:text-spa-gold/60'
              }`}
            >
              Daily Log
              {activeTab === 'log' && (
                <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-spa-gold" />
              )}
            </button>
            <button 
              onClick={() => setActiveTab('clients')}
              className={`px-8 py-4 text-[10px] font-bold uppercase tracking-[0.3em] transition-all relative ${
                activeTab === 'clients' ? 'text-spa-gold' : 'text-spa-gold/30 hover:text-spa-gold/60'
              }`}
            >
              Client Directory
              {activeTab === 'clients' && (
                <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-spa-gold" />
              )}
            </button>
            <button 
              onClick={() => setActiveTab('bookings')}
              className={`px-8 py-4 text-[10px] font-bold uppercase tracking-[0.3em] transition-all relative ${
                activeTab === 'bookings' ? 'text-spa-gold' : 'text-spa-gold/30 hover:text-spa-gold/60'
              }`}
            >
              Bookings
              {activeTab === 'bookings' && (
                <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-spa-gold" />
              )}
            </button>
            {userRole === 'admin' && (
              <button 
                onClick={() => setActiveTab('reports')}
                className={`px-8 py-4 text-[10px] font-bold uppercase tracking-[0.3em] transition-all relative ${
                  activeTab === 'reports' ? 'text-spa-gold' : 'text-spa-gold/30 hover:text-spa-gold/60'
                }`}
              >
                Reports
                {activeTab === 'reports' && (
                  <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-spa-gold" />
                )}
              </button>
            )}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
            >
              {activeTab === 'log' ? (
                <>
                  {/* Total Income Display */}
                  {userRole === 'admin' && (
                    <motion.div 
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="bg-spa-ink p-10 text-white shadow-2xl relative border-l-4 border-spa-gold"
                    >
                      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                        <div>
                          <div className="flex items-center gap-2 mb-4 text-spa-gold">
                            <TrendingUp className="w-4 h-4" />
                            <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Weekly Revenue Summary</span>
                          </div>
                          <div className="text-7xl font-light serif tracking-tight text-white">
                            R{weeklySales.filter(s => !s.isCancelled).reduce((sum, s) => sum + s.price, 0)}
                          </div>
                        </div>
                        <div className="text-right space-y-4">
                          <div className="flex flex-col items-end">
                            <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-1">
                              Volume (7 Days)
                            </div>
                            <div className="text-2xl font-light serif">
                              {weeklySales.length} <span className="text-sm uppercase tracking-widest opacity-50">Treatments</span>
                            </div>
                          </div>
                          
                          <div className="pt-4 border-t border-white/10 space-y-1">
                            <div className="flex justify-between gap-8 text-[9px] font-bold uppercase tracking-widest text-spa-gold/60">
                              <span>Cash</span>
                              <span className="text-white">R{dashboardMetrics.todayPaymentTotals.Cash}</span>
                            </div>
                            <div className="flex justify-between gap-8 text-[9px] font-bold uppercase tracking-widest text-spa-gold/60">
                              <span>Card</span>
                              <span className="text-white">R{dashboardMetrics.todayPaymentTotals.Card}</span>
                            </div>
                            <div className="flex justify-between gap-8 text-[9px] font-bold uppercase tracking-widest text-spa-gold/60">
                              <span>EFT</span>
                              <span className="text-white">R{dashboardMetrics.todayPaymentTotals.EFT}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

              {/* Sales History */}
              <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
                <div className="flex items-center justify-between mb-10 border-b border-spa-gold/10 pb-6">
                  <div className="flex items-center gap-3">
                    <History className="w-5 h-5 text-spa-gold" />
                    <h2 className="text-2xl serif font-medium text-spa-ink uppercase tracking-widest">Weekly Log <span className="text-spa-gold/40 text-xs lowercase italic font-normal">(Last 7 Days)</span></h2>
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-spa-gold/40">
                    {new Date().getFullYear()} Archive
                  </span>
                </div>

                <div className="space-y-6">
                  <AnimatePresence initial={false}>
                    {weeklySales.length === 0 ? (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-center py-20 text-spa-gold/30 italic serif text-xl"
                      >
                        The weekly log is currently empty.
                      </motion.div>
                    ) : (
                      weeklySales.map((sale) => (
                        <motion.div
                          key={sale.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className="group flex justify-between items-start sm:items-center p-6 bg-spa-cream/20 border border-transparent hover:border-spa-gold/20 hover:bg-white transition-all gap-4"
                        >
                          <div className="flex gap-4 sm:gap-6 items-center min-w-0 flex-1">
                            <div className="w-10 h-10 sm:w-12 sm:h-12 shrink-0 rounded-full border border-spa-gold/20 flex items-center justify-center text-spa-gold serif text-lg sm:text-xl">
                              {sale.customerName.charAt(0)}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="font-medium text-spa-ink serif text-lg sm:text-xl tracking-wide truncate">{sale.customerName}</div>
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
                                <span className="text-[9px] sm:text-[10px] text-spa-gold font-bold uppercase tracking-widest shrink-0">{sale.serviceType}</span>
                                <span className="w-1 h-1 rounded-full bg-spa-gold/30 hidden sm:block"></span>
                                <span className="px-2 py-0.5 bg-spa-gold/10 text-spa-gold text-[7px] sm:text-[8px] font-bold uppercase tracking-tighter border border-spa-gold/20 shrink-0">
                                  {sale.paymentMethod}
                                </span>
                                <span className="w-1 h-1 rounded-full bg-spa-gold/30 hidden sm:block"></span>
                                {sale.customerPhone && (
                                  <>
                                    <span className="text-[9px] sm:text-[10px] text-spa-ink/60 font-medium flex items-center gap-1 shrink-0">
                                      <Phone className="w-2.5 h-2.5" /> {sale.customerPhone}
                                    </span>
                                    <span className="w-1 h-1 rounded-full bg-spa-gold/30 hidden sm:block"></span>
                                  </>
                                )}
                                <span className="text-[9px] sm:text-[10px] text-spa-ink/40 font-medium shrink-0">
                                  {new Date(sale.timestamp).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' })} • {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                                <span className="w-1 h-1 rounded-full bg-spa-gold/30 hidden sm:block"></span>
                                <span className="text-[9px] sm:text-[10px] text-spa-gold/60 font-bold uppercase tracking-tighter italic">
                                  Cashier: {sale.cashierName}
                                </span>
                              </div>
                              {sale.isCancelled && (
                                <div className="flex items-center gap-2 mt-1.5 pt-1.5 border-t border-red-100/50 w-fit">
                                  <span className="text-[8px] font-bold uppercase tracking-widest text-red-600">Cancelled</span>
                                  <span className="text-[7px] text-spa-ink/30 uppercase tracking-tighter">By {sale.cancelledBy}</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-4 sm:gap-8 shrink-0">
                            <span className={`text-xl sm:text-2xl font-light serif ${sale.isCancelled ? 'text-spa-ink/30 line-through' : 'text-spa-ink'}`}>R{sale.price}</span>
                            {!sale.isCancelled && (
                              <button 
                                onClick={() => {
                                  setCancellingSaleId(sale.id);
                                  setShowCancelModal(true);
                                }}
                                className="p-2 text-spa-gold/60 hover:text-red-800 transition-colors shrink-0"
                                title="Cancel order"
                              >
                                <LogOut className="w-4 h-4 rotate-180" />
                              </button>
                            )}
                          </div>
                        </motion.div>
                      ))
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </>
          ) : activeTab === 'clients' ? (
            /* Client Directory View */
            <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-10 border-b border-spa-gold/10 pb-6 gap-6">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-5 h-5 text-spa-gold" />
                  <h2 className="text-2xl serif font-medium text-spa-ink uppercase tracking-widest">Client Directory</h2>
                </div>
                
                <div className="relative group max-w-xs w-full">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder="Search clients..."
                    className="w-full pl-10 pr-4 py-2 bg-spa-cream/30 border border-spa-gold/10 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/30 text-xs uppercase tracking-widest"
                  />
                </div>
              </div>

              <div className="space-y-4">
                {filteredCustomers.length === 0 ? (
                  <div className="text-center py-20 text-spa-gold/30 italic serif text-xl">
                    No clients found matching your search.
                  </div>
                ) : (
                  filteredCustomers.map((client) => (
                    <div 
                      key={`${client.name}-${client.phone}`}
                      className="p-6 border border-spa-gold/5 bg-spa-cream/5 hover:bg-spa-cream/10 transition-all"
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div className="flex gap-6 items-center">
                          <div className="w-14 h-14 rounded-full bg-spa-ink text-spa-gold flex items-center justify-center serif text-2xl border border-spa-gold/20">
                            {client.name.charAt(0)}
                          </div>
                          <div>
                            <h3 className="text-xl serif font-medium text-spa-ink tracking-wide">{client.name}</h3>
                            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1">
                              {client.phone && (
                                <span className="text-[10px] text-spa-gold font-bold uppercase tracking-widest flex items-center gap-1.5">
                                  <Phone className="w-3 h-3" /> {client.phone}
                                </span>
                              )}
                              {client.email && (
                                <span className="text-[10px] text-spa-ink/60 font-medium flex items-center gap-1.5">
                                  <Mail className="w-3 h-3" /> {client.email}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold/40 mb-1">Last Visit</div>
                          <div className="text-sm font-medium text-spa-ink">
                            {new Date(client.lastVisit).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-6 pt-4 border-t border-spa-gold/5">
                        <div className="text-[9px] font-bold uppercase tracking-widest text-spa-gold/40 mb-2">Treatments History</div>
                        <div className="flex flex-wrap gap-2">
                          {client.services.map((service, idx) => (
                            <span key={idx} className="px-3 py-1 bg-spa-gold/5 text-spa-gold text-[9px] font-bold uppercase tracking-widest border border-spa-gold/10">
                              {service}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : activeTab === 'reports' ? (
            /* Reports View */
            <div className="space-y-12">
              {/* Monthly Income Chart */}
              <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-10 border-b border-spa-gold/10 pb-6 gap-4">
                  <div className="flex items-center gap-3">
                    <LineChartIcon className="w-5 h-5 text-spa-gold" />
                    <h2 className="text-xl sm:text-2xl serif font-medium text-spa-ink uppercase tracking-widest">Monthly Revenue</h2>
                  </div>
                  <div className="flex items-center gap-3 bg-spa-cream/30 p-2 border border-spa-gold/5">
                    <select 
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(Number(e.target.value))}
                      className="bg-transparent border-none px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-spa-ink focus:outline-none"
                    >
                      {Array.from({ length: 21 }, (_, i) => new Date().getFullYear() + 10 - i).map(year => (
                        <option key={year} value={year}>{year}</option>
                      ))}
                    </select>
                    <div className="text-[9px] font-bold uppercase tracking-widest text-spa-gold/60 whitespace-nowrap border-l border-spa-gold/20 pl-3">
                      Overview {selectedYear}
                    </div>
                  </div>
                </div>
                
                <div className="h-[350px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={reportData.monthlyChart}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E4E3E0" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#141414', fontSize: 10, fontWeight: 600 }}
                        dy={10}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#141414', fontSize: 10, fontWeight: 600 }}
                        tickFormatter={(value) => `R${value}`}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#141414', 
                          border: 'none', 
                          borderRadius: '0',
                          color: '#fff',
                          fontSize: '12px',
                          fontFamily: 'serif'
                        }}
                        itemStyle={{ color: '#F27D26' }}
                        formatter={(value) => [`R${value}`, 'Revenue']}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#F27D26" 
                        strokeWidth={3} 
                        dot={{ fill: '#F27D26', strokeWidth: 2, r: 4 }}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                {/* Daily Sales Bar Chart */}
                <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
                  <div className="flex items-center gap-3 mb-10 border-b border-spa-gold/10 pb-6">
                    <BarChart3 className="w-5 h-5 text-spa-gold" />
                    <h2 className="text-xl serif font-medium text-spa-ink uppercase tracking-widest">Last 7 Days</h2>
                  </div>
                  <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={reportData.dailyChart}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E4E3E0" />
                        <XAxis 
                          dataKey="name" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#141414', fontSize: 9, fontWeight: 600 }}
                        />
                        <YAxis hide />
                        <Tooltip 
                          cursor={{ fill: '#F5F2ED' }}
                          contentStyle={{ backgroundColor: '#141414', border: 'none', borderRadius: '0', color: '#fff' }}
                          formatter={(value) => [`R${value}`, 'Sales']}
                        />
                        <Bar dataKey="value" fill="#F27D26" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Payment Method Pie Chart */}
                <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
                  <div className="flex items-center gap-3 mb-10 border-b border-spa-gold/10 pb-6">
                    <PieChartIcon className="w-5 h-5 text-spa-gold" />
                    <h2 className="text-xl serif font-medium text-spa-ink uppercase tracking-widest">Payment Mix</h2>
                  </div>
                  <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={reportData.paymentChart}
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {reportData.paymentChart.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={['#141414', '#F27D26', '#E4E3E0'][index % 3]} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#141414', border: 'none', borderRadius: '0', color: '#fff' }}
                          formatter={(value) => [`R${value}`, 'Total']}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="flex justify-center gap-6 mt-4">
                      {reportData.paymentChart.map((entry, index) => (
                        <div key={entry.name} className="flex items-center gap-2">
                          <div className="w-3 h-3" style={{ backgroundColor: ['#141414', '#F27D26', '#E4E3E0'][index % 3] }}></div>
                          <span className="text-[9px] font-bold uppercase tracking-widest text-spa-ink/60">{entry.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Weekly Performance */}
              <div className="bg-spa-ink p-10 text-white shadow-2xl border-l-4 border-spa-gold">
                <div className="flex items-center gap-3 mb-8">
                  <TrendingUp className="w-5 h-5 text-spa-gold" />
                  <h2 className="text-xl serif font-light uppercase tracking-[0.2em]">Weekly Performance</h2>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {reportData.weeklyChart.map((week, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-spa-gold/60">{week.name}</div>
                      <div className="text-3xl font-light serif">R{week.value}</div>
                      <div className="h-1 bg-white/10 w-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min((week.value / (Math.max(...reportData.weeklyChart.map(w => w.value)) || 1)) * 100, 100)}%` }}
                          className="h-full bg-spa-gold"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Bookings View */
            <div className="space-y-12">
              {/* New Booking Form */}
              <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
                <div className="flex items-center gap-3 mb-8 border-b border-spa-gold/10 pb-6">
                  <Plus className="w-5 h-5 text-spa-gold" />
                  <h2 className="text-2xl serif font-medium text-spa-ink uppercase tracking-widest">New Booking</h2>
                </div>

                <form onSubmit={handleSaveBooking} className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">Customer Name</label>
                      <div className="relative group">
                        <User className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                        <input
                          type="text"
                          required
                          value={bookingName}
                          onChange={(e) => setBookingName(e.target.value)}
                          placeholder="Client name..."
                          className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink placeholder:text-spa-gold/20 serif text-lg"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">Treatment</label>
                      <select
                        required
                        value={bookingServiceIndex ?? ''}
                        onChange={(e) => setBookingServiceIndex(e.target.value ? Number(e.target.value) : null)}
                        className="w-full py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg"
                      >
                        <option value="">Select a service...</option>
                        {SERVICES.map((s, i) => (
                          <option key={i} value={i}>{s.name} - R{s.price}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">Date</label>
                      <div className="relative group">
                        <Calendar className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                        <input
                          type="date"
                          required
                          value={bookingDate}
                          onChange={(e) => setBookingDate(e.target.value)}
                          className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">Time</label>
                      <div className="relative group">
                        <Clock className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-4 text-spa-gold/40 group-focus-within:text-spa-gold transition-colors" />
                        <input
                          type="time"
                          required
                          value={bookingTime}
                          onChange={(e) => setBookingTime(e.target.value)}
                          className="w-full pl-8 pr-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-5 bg-spa-ink text-white font-bold uppercase tracking-[0.3em] text-xs hover:bg-spa-ink/90 transition-all shadow-xl active:scale-[0.98] flex items-center justify-center gap-3"
                  >
                    <Calendar className="w-4 h-4" />
                    Schedule Appointment
                  </button>
                </form>

                <AnimatePresence>
                  {showBookingSuccess && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mt-6 p-4 bg-emerald-50 text-emerald-700 text-center text-[10px] font-bold uppercase tracking-widest border border-emerald-100"
                    >
                      Appointment Scheduled Successfully
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Upcoming Appointments */}
              <div className="bg-white p-8 shadow-xl border border-spa-gold/10">
                <div className="flex items-center gap-3 mb-10 border-b border-spa-gold/10 pb-6">
                  <Clock className="w-5 h-5 text-spa-gold" />
                  <h2 className="text-2xl serif font-medium text-spa-ink uppercase tracking-widest">Upcoming Appointments</h2>
                </div>

                <div className="space-y-4">
                  {allBookings.length === 0 ? (
                    <div className="text-center py-20 text-spa-gold/30 italic serif text-xl">
                      No appointments found in history.
                    </div>
                  ) : (
                    allBookings.map((booking) => (
                      <div 
                        key={booking.id}
                        className={`p-6 border border-spa-gold/5 transition-all ${booking.isCancelled ? 'bg-red-50/30' : 'bg-spa-cream/5 hover:bg-spa-cream/10'}`}
                      >
                        <div className="flex justify-between items-start sm:items-center gap-4">
                          <div className="flex gap-4 sm:gap-6 items-center min-w-0 flex-1">
                            <div className={`w-10 h-10 sm:w-12 sm:h-12 shrink-0 rounded-full flex items-center justify-center serif text-lg sm:text-xl border ${booking.isCancelled ? 'bg-red-100 text-red-600 border-red-200' : 'bg-spa-gold/10 text-spa-gold border-spa-gold/20'}`}>
                              {booking.customerName.charAt(0)}
                            </div>
                            <div className="min-w-0 flex-1">
                              <h3 className={`text-base sm:text-lg serif font-medium tracking-wide truncate ${booking.isCancelled ? 'text-spa-ink/40 line-through' : 'text-spa-ink'}`}>{booking.customerName}</h3>
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1">
                                <span className={`text-[9px] sm:text-[10px] font-bold uppercase tracking-widest shrink-0 ${booking.isCancelled ? 'text-red-400' : 'text-spa-gold'}`}>{booking.serviceType}</span>
                                <span className="w-1 h-1 rounded-full bg-spa-gold/30 hidden sm:block"></span>
                                <span className="text-[9px] sm:text-[10px] text-spa-ink/60 font-medium flex items-center gap-1 shrink-0">
                                  <Calendar className="w-2.5 h-2.5" /> {new Date(booking.date).toLocaleDateString('en-ZA', { day: 'numeric', month: 'short' })}
                                </span>
                                <span className="w-1 h-1 rounded-full bg-spa-gold/30 hidden sm:block"></span>
                                <span className="text-[9px] sm:text-[10px] text-spa-ink/60 font-medium flex items-center gap-1 shrink-0">
                                  <Clock className="w-2.5 h-2.5" /> {booking.time}
                                </span>
                              </div>
                              {booking.isCancelled && (
                                <div className="flex items-center gap-2 mt-2">
                                  <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-widest text-red-600">CANCELLED</span>
                                </div>
                              )}
                            </div>
                          </div>
                          {!booking.isCancelled && (
                            <button 
                              onClick={() => {
                                setCancellingBookingId(booking.id);
                                setShowCancelModal(true);
                              }}
                              className="p-2 text-spa-gold/60 hover:text-red-800 transition-colors shrink-0"
                              title="Cancel Booking"
                            >
                              <LogOut className="w-4 h-4 rotate-180" />
                            </button>
                          )}
                        </div>
                        
                        {booking.isCancelled && (
                          <div className="mt-4 pt-4 border-t border-red-100 space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="text-[9px] font-bold uppercase tracking-widest text-red-600/60">Reason:</span>
                              <span className="text-xs text-spa-ink/70 italic serif">{booking.cancellationReason}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="text-[9px] font-bold uppercase tracking-widest text-red-600/60">Cancelled By:</span>
                                <span className="text-[10px] font-medium text-spa-ink/60">{booking.cancelledBy}</span>
                              </div>
                              <div className="text-[9px] text-spa-ink/30 font-medium">
                                {new Date(booking.cancelledAt!).toLocaleString('en-ZA', { 
                                  day: 'numeric', 
                                  month: 'short', 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
          </motion.div>
        </AnimatePresence>
      </section>
      </div>
    </main>

      {/* Cancellation Modal */}
      <AnimatePresence>
        {showCancelModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-spa-ink/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white w-full max-w-md p-10 shadow-2xl border border-spa-gold/20"
            >
              <div className="flex items-center gap-3 mb-8 border-b border-spa-gold/10 pb-4">
                <LogOut className="w-5 h-5 text-red-600 rotate-180" />
                <h2 className="text-2xl serif font-medium text-spa-ink uppercase tracking-widest">
                  {cancellingBookingId ? 'Cancel Booking' : 'Cancel Order'}
                </h2>
              </div>
              
              <form onSubmit={handleConfirmCancellation} className="space-y-6">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">Admin Name</label>
                  <input
                    type="text"
                    required
                    value={cancellingAdminName}
                    onChange={(e) => setCancellingAdminName(e.target.value)}
                    placeholder="Enter your name..."
                    className="w-full px-4 py-3 bg-transparent border-b border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg"
                  />
                </div>
                
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-spa-gold mb-3">Reason for Cancellation</label>
                  <textarea
                    required
                    value={cancellationReason}
                    onChange={(e) => setCancellationReason(e.target.value)}
                    placeholder="Provide a reason..."
                    rows={3}
                    className="w-full px-4 py-3 bg-transparent border border-spa-gold/20 focus:border-spa-gold focus:outline-none transition-all text-spa-ink serif text-lg resize-none"
                  />
                </div>
                
                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowCancelModal(false);
                      setCancellingSaleId(null);
                      setCancellingBookingId(null);
                      setCancellationReason('');
                      setCancellingAdminName('');
                    }}
                    className="flex-1 py-4 border border-spa-gold/20 text-[10px] font-bold uppercase tracking-widest text-spa-gold hover:bg-spa-cream transition-all"
                  >
                    Go Back
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-4 bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg"
                  >
                    Confirm Cancellation
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="mt-24 text-center px-4 max-w-2xl mx-auto border-t border-spa-gold/10 pt-12">
        <div className="flex justify-center mb-6">
          <svg width="60" height="45" viewBox="0 0 120 80" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-spa-gold opacity-30">
            <path d="M25 65c-10 0-18-8-18-18 0-9 7-16 16-17 1-10 10-18 20-18 8 0 15 5 18 12 3-2 6-3 10-3 9 0 16 7 16 16 0 1-1 2-1 3 8 2 14 9 14 17 0 10-8 18-18 18H25z" stroke="currentColor" strokeWidth="2" fill="none" />
          </svg>
        </div>
        <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-spa-gold mb-2">
          Serenity Cloud Spa
        </p>
        <p className="serif italic text-spa-ink/40 text-sm mb-6">
          "Serenity within..."
        </p>
        <div className="flex justify-center gap-8 text-[10px] font-bold uppercase tracking-widest text-spa-gold/60 mb-8">
          <span className="flex items-center gap-2">
            <Phone className="w-3 h-3" /> {CONTACT_NUMBER}
          </span>
        </div>
        <p className="text-[9px] uppercase tracking-[0.2em] text-spa-gold/80 mb-2">
          Registration: 2026/211077/07
        </p>
        <p className="text-[9px] uppercase tracking-[0.2em] text-spa-gold/80">
          &copy; {new Date().getFullYear()} Premium Management Interface
        </p>
      </footer>
    </div>
  );
}
