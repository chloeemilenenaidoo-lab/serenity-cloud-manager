package com.serenity.cloudspa;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
